import { Controller } from '@nestjs/common';

@Controller('students')
export class StudentsController {}
