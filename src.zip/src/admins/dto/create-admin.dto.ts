import { IsEmail, IsString } from 'class-validator';

export class CreateAdminDto {
  @IsEmail()
  name: string;

  @IsString()
  password: string;

  @IsString()
  phone: string;
}
