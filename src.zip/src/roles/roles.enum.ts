export enum Role {
  Admin = 'admin',
  Teacher = 'teacher',
  Student = 'student',
}